#pragma once

void Car_Level_Init(void);

void Car_Level_Update(void);

void Car_Level_Exit(void);